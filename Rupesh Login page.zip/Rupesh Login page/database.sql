CREATE DATABASE IF NOT EXISTS nodejs_login
USE nodejs_login;
CREATE TABLE users ( 
	id int AUTO_INCREMENT,
	username varchar(20),
	fullname varchar(20),
	password varchar(128),
	PRIMARY KEY (id)
);
