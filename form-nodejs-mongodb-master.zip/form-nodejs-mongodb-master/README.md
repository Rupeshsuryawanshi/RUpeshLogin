# Save form data to MongoDB 

In this tutorial we will create simple form that will save user data to server implemented in Node.js with MongoDB database and allow us to see saved data on a separate page in JSON format.

Link to tutorial: [http://programmingmentor.com/post/save-form-nodejs-mongodb/](http://programmingmentor.com/post/save-form-nodejs-mongodb/)

Link to video: [https://youtu.be/epo-70M8hNo](https://youtu.be/epo-70M8hNo)
